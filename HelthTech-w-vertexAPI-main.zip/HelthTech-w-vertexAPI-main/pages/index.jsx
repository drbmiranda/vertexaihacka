import { Header } from "../components/Header";

const HomePage = () => {
    return (
        <Header />
    ) 
}

export default HomePage;